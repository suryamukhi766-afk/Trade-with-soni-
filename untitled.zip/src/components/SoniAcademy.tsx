import React, { useState, useEffect } from 'react';
import { ACADEMY_MODULES } from '../data/marketData';
import { CourseModule, CourseLesson } from '../types/trading';
import { 
  BookOpen, 
  CheckCircle, 
  PlayCircle, 
  Clock, 
  ShieldCheck, 
  Award, 
  Sparkles, 
  ChevronRight, 
  Flame, 
  Check, 
  Languages, 
  FileText, 
  BookmarkCheck, 
  CheckCircle2,
  GraduationCap
} from 'lucide-react';

export const SoniAcademy: React.FC = () => {
  // Language selection: 'EN' for English, 'HI' for Hindi / Hinglish
  const [lang, setLang] = useState<'EN' | 'HI'>(() => {
    try {
      const saved = localStorage.getItem('tws_academy_lang');
      return (saved === 'EN' || saved === 'HI') ? saved : 'HI';
    } catch {
      return 'HI';
    }
  });

  const handleSetLang = (newLang: 'EN' | 'HI') => {
    setLang(newLang);
    try {
      localStorage.setItem('tws_academy_lang', newLang);
    } catch {}
  };

  const [selectedModule, setSelectedModule] = useState<CourseModule>(ACADEMY_MODULES[0]);
  const [selectedLesson, setSelectedLesson] = useState<CourseLesson>(ACADEMY_MODULES[0].lessons[0]);
  const [isPlayingVideo, setIsPlayingVideo] = useState(false);
  const [activeTab, setActiveTab] = useState<'notes' | 'video' | 'rules'>('notes');

  // Track completed lessons
  const [completedLessonIds, setCompletedLessonIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('tws_completed_lessons');
      return saved ? JSON.parse(saved) : ['les-1'];
    } catch {
      return ['les-1'];
    }
  });

  const toggleLessonComplete = (id: string) => {
    setCompletedLessonIds(prev => {
      const next = prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id];
      try {
        localStorage.setItem('tws_completed_lessons', JSON.stringify(next));
      } catch {}
      return next;
    });
  };

  // Pre-trade checklist state
  const [checklist, setChecklist] = useState({
    higherTimeframe: false,
    vwapConfluence: false,
    sectorAlignment: false,
    riskUnderTwoPercent: false,
    stopLossPredefined: false,
    noRevengeState: false
  });

  const toggleCheck = (key: keyof typeof checklist) => {
    setChecklist(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const completedChecks = Object.values(checklist).filter(Boolean).length;
  const isTradeApproved = completedChecks >= 5;

  // Flatten all 10 lessons for progress calculations
  const allLessons = ACADEMY_MODULES.flatMap(m => m.lessons);
  const totalLessonsCount = allLessons.length;
  const progressPercent = Math.round((completedLessonIds.length / totalLessonsCount) * 100);

  const isCurrentCompleted = completedLessonIds.includes(selectedLesson.id);

  return (
    <div className="space-y-6">
      {/* Academy Header */}
      <div className="bg-gradient-to-r from-slate-900 via-amber-950/20 to-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 flex-wrap gap-y-1">
            <span className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/30">
              <BookOpen className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-extrabold text-white tracking-tight">
              {lang === 'HI' ? 'सोनी ट्रेडिंग एकेडमी' : 'Soni Trading Academy'}
            </h2>
            <span className="bg-amber-500/20 text-amber-400 text-xs font-bold px-2 py-0.5 rounded-full border border-amber-500/30">
              {lang === 'HI' ? '10 मास्टर क्लास' : '10 Master Lessons'}
            </span>
            <span className="bg-emerald-500/20 text-emerald-400 text-xs font-bold px-2 py-0.5 rounded-full border border-emerald-500/30">
              {lang === 'HI' ? 'द्विभाषी (Hindi + English)' : 'Bilingual Edition'}
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            {lang === 'HI'
              ? 'जीरो से प्रो प्राइस एक्शन और ऑप्शन बाइंग ट्रेडर बनें। 9:20 AM ब्रेकआउट, VWAP ट्रैपिंग और 1% रिस्क मैनेजमेंट के नियम सीखें।'
              : 'From zero to disciplined institutional price action trader. Master the 9:20 AM Setup, Open Interest reading, and risk algorithms.'}
          </p>
        </div>

        {/* Language Switcher & Progress Badges */}
        <div className="flex items-center space-x-3 text-xs font-mono">
          {/* Language Switcher Button */}
          <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-amber-500/40 shadow-inner">
            <button
              onClick={() => handleSetLang('HI')}
              className={`flex items-center space-x-1 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                lang === 'HI'
                  ? 'bg-amber-500 text-slate-950 shadow-md font-extrabold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Languages className="w-3.5 h-3.5" />
              <span>हिंदी (HI)</span>
            </button>
            <button
              onClick={() => handleSetLang('EN')}
              className={`flex items-center space-x-1 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                lang === 'EN'
                  ? 'bg-amber-500 text-slate-950 shadow-md font-extrabold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>English (EN)</span>
            </button>
          </div>

          {/* Progress Tracker */}
          <div className="bg-slate-950/80 px-3 py-2 rounded-xl border border-slate-800">
            <span className="text-slate-500 block text-[10px]">
              {lang === 'HI' ? 'प्रोग्रेस' : 'PROGRESS'}
            </span>
            <span className="text-emerald-400 font-bold">
              {completedLessonIds.length}/{totalLessonsCount} ({progressPercent}%)
            </span>
          </div>
        </div>
      </div>

      {/* Main Grid: Curriculum (Left) + Lesson Viewer (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Modules Sidebar (5 cols) */}
        <div className="lg:col-span-5 space-y-3">
          <div className="flex items-center justify-between px-1">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <GraduationCap className="w-4 h-4 text-amber-400" />
              <span>{lang === 'HI' ? '10 लेसन का संपूर्ण कोर्स' : 'Complete 10-Lesson Curriculum'}</span>
            </h3>
            <span className="text-[10px] text-amber-400 font-mono font-semibold">
              {completedLessonIds.length} {lang === 'HI' ? 'पूरे हुए' : 'Done'}
            </span>
          </div>

          {ACADEMY_MODULES.map((mod) => {
            const isSelectedMod = selectedModule.id === mod.id;
            return (
              <div 
                key={mod.id}
                className={`bg-slate-900/90 border rounded-2xl p-4 transition-all shadow-xl ${
                  isSelectedMod ? 'border-amber-500/40 bg-slate-900' : 'border-slate-800 hover:border-slate-700'
                }`}
              >
                <div 
                  onClick={() => setSelectedModule(mod)}
                  className="cursor-pointer"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold font-mono text-amber-400 uppercase tracking-wider">
                      {lang === 'HI' ? mod.badgeHi : mod.badge}
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono">
                      {mod.lessons.length} {lang === 'HI' ? 'लेसन' : 'Lessons'}
                    </span>
                  </div>
                  <h4 className="font-extrabold text-sm text-white mt-1">
                    {lang === 'HI' ? mod.titleHi : mod.title}
                  </h4>
                  <p className="text-xs text-slate-400 mt-0.5">
                    {lang === 'HI' ? mod.subtitleHi : mod.subtitle}
                  </p>
                </div>

                {/* Sub-lessons */}
                <div className="mt-3 pt-3 border-t border-slate-800/80 space-y-1.5">
                  {mod.lessons.map(les => {
                    const isSelectedLes = selectedLesson.id === les.id;
                    const isDone = completedLessonIds.includes(les.id);

                    return (
                      <div
                        key={les.id}
                        onClick={() => {
                          setSelectedModule(mod);
                          setSelectedLesson(les);
                          setIsPlayingVideo(false);
                        }}
                        className={`p-2 rounded-xl text-xs flex items-center justify-between cursor-pointer transition-all ${
                          isSelectedLes 
                            ? 'bg-amber-500/15 text-amber-300 font-semibold border border-amber-500/30 shadow-sm' 
                            : 'hover:bg-slate-800/60 text-slate-300'
                        }`}
                      >
                        <div className="flex items-center space-x-2 truncate">
                          {isDone ? (
                            <CheckCircle2 className="w-3.5 h-3.5 shrink-0 text-emerald-400" />
                          ) : (
                            <span className="w-3.5 h-3.5 rounded-full border border-slate-600 flex items-center justify-center text-[9px] font-mono text-slate-400 shrink-0">
                              {les.order}
                            </span>
                          )}
                          <span className="truncate">
                            {lang === 'HI' ? les.titleHi : les.title}
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-500 font-mono shrink-0 ml-2">
                          {les.duration}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected Lesson Viewer (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-5">
            {/* Lesson Title Header with Order & Mark Done Button */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
              <div>
                <div className="flex items-center space-x-2">
                  <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-mono font-bold">
                    {lang === 'HI' ? `लेसन #${selectedLesson.order}` : `LESSON #${selectedLesson.order}`}
                  </span>
                  <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px] text-emerald-400 font-bold font-mono">
                    {selectedLesson.difficulty}
                  </span>
                  <span className="text-[11px] text-slate-400 font-mono flex items-center gap-1">
                    <Clock className="w-3 h-3 text-amber-400" />
                    {selectedLesson.duration}
                  </span>
                </div>
                <h3 className="text-lg font-black text-white mt-1.5 tracking-tight">
                  {lang === 'HI' ? selectedLesson.titleHi : selectedLesson.title}
                </h3>
              </div>

              {/* Complete Toggle Button */}
              <button
                onClick={() => toggleLessonComplete(selectedLesson.id)}
                className={`flex items-center space-x-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all shrink-0 shadow-md ${
                  isCurrentCompleted
                    ? 'bg-emerald-500 text-slate-950 hover:bg-emerald-400'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
                }`}
              >
                <BookmarkCheck className="w-4 h-4" />
                <span>
                  {isCurrentCompleted 
                    ? (lang === 'HI' ? 'पूर्ण हुआ ✅' : 'Completed ✅') 
                    : (lang === 'HI' ? 'मार्क करें पूरा' : 'Mark as Done')}
                </span>
              </button>
            </div>

            {/* View Mode Switcher: Study Notes / Video Simulator / Rules */}
            <div className="flex items-center space-x-2 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
              <button
                onClick={() => setActiveTab('notes')}
                className={`flex-1 flex items-center justify-center space-x-1.5 py-1.5 rounded-lg font-semibold transition-all ${
                  activeTab === 'notes'
                    ? 'bg-slate-800 text-emerald-400 border border-slate-700 shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>{lang === 'HI' ? 'अध्ययन नोट्स' : 'Detailed Notes'}</span>
              </button>

              <button
                onClick={() => setActiveTab('video')}
                className={`flex-1 flex items-center justify-center space-x-1.5 py-1.5 rounded-lg font-semibold transition-all ${
                  activeTab === 'video'
                    ? 'bg-slate-800 text-amber-400 border border-slate-700 shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <PlayCircle className="w-3.5 h-3.5" />
                <span>{lang === 'HI' ? 'वीडियो सिमुलेटर' : 'Video Lecture'}</span>
              </button>

              <button
                onClick={() => setActiveTab('rules')}
                className={`flex-1 flex items-center justify-center space-x-1.5 py-1.5 rounded-lg font-semibold transition-all ${
                  activeTab === 'rules'
                    ? 'bg-slate-800 text-cyan-400 border border-slate-700 shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{lang === 'HI' ? 'गोल्डन रूल्स' : 'Key Rules'}</span>
              </button>
            </div>

            {/* Content Based on Active Mode */}
            {activeTab === 'video' ? (
              /* Simulated Video Player */
              <div className="aspect-video w-full rounded-xl bg-slate-950 border border-slate-800 relative overflow-hidden flex flex-col items-center justify-center text-center p-6 shadow-inner">
                {isPlayingVideo ? (
                  <div className="space-y-3">
                    <div className="w-12 h-12 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center mx-auto text-emerald-400 animate-pulse">
                      <Flame className="w-6 h-6" />
                    </div>
                    <h4 className="text-white font-extrabold text-base">
                      {lang === 'HI' ? 'मास्टरक्लास लेक्चर चल रहा है...' : 'Streaming Masterclass Lecture...'}
                    </h4>
                    <p className="text-xs text-slate-400 max-w-sm mx-auto">
                      {lang === 'HI' ? selectedLesson.summaryHi : selectedLesson.summary}
                    </p>
                    <div className="w-48 h-1.5 bg-slate-800 rounded-full mx-auto overflow-hidden">
                      <div className="h-full bg-amber-400 rounded-full animate-pulse w-2/3"></div>
                    </div>
                    <button
                      onClick={() => setIsPlayingVideo(false)}
                      className="text-xs text-slate-400 hover:text-white underline pt-2"
                    >
                      {lang === 'HI' ? 'वीडियो रोकें' : 'Pause Video'}
                    </button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <button
                      onClick={() => setIsPlayingVideo(true)}
                      className="w-16 h-16 rounded-full bg-gradient-to-tr from-amber-500 to-emerald-500 hover:scale-105 active:scale-95 transition-all flex items-center justify-center shadow-xl shadow-amber-500/20 mx-auto"
                    >
                      <PlayCircle className="w-8 h-8 text-slate-950" />
                    </button>
                    <h4 className="text-white font-extrabold text-sm sm:text-base">
                      {lang === 'HI' ? selectedLesson.titleHi : selectedLesson.title}
                    </h4>
                    <div className="flex items-center justify-center space-x-3 text-xs text-slate-400 font-mono">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-amber-400" />
                        {selectedLesson.duration}
                      </span>
                      <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px] text-emerald-400 font-bold">
                        {selectedLesson.difficulty}
                      </span>
                    </div>
                  </div>
                )}
              </div>
            ) : activeTab === 'notes' ? (
              /* Detailed Notes & Explanation */
              <div className="space-y-4">
                <div className="p-4 bg-slate-950/80 rounded-xl border border-slate-800 space-y-2">
                  <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1">
                    <FileText className="w-3.5 h-3.5" />
                    <span>{lang === 'HI' ? 'लेसन का सार (Core Summary)' : 'Lesson Summary'}</span>
                  </h4>
                  <p className="text-xs text-slate-300 leading-relaxed font-sans">
                    {lang === 'HI' ? selectedLesson.summaryHi : selectedLesson.summary}
                  </p>
                </div>

                <div className="p-4 bg-slate-950/60 rounded-xl border border-slate-800/80 space-y-2">
                  <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1">
                    <BookOpen className="w-3.5 h-3.5" />
                    <span>{lang === 'HI' ? 'विस्तृत पाठ्य सामग्री (In-Depth Explanation)' : 'Deep-Dive Guide'}</span>
                  </h4>
                  <p className="text-xs text-slate-200 leading-relaxed font-sans whitespace-pre-line">
                    {lang === 'HI' 
                      ? (selectedLesson.contentHi || selectedLesson.summaryHi) 
                      : (selectedLesson.content || selectedLesson.summary)}
                  </p>
                </div>
              </div>
            ) : (
              /* Key Rules & Takeaways */
              <div className="bg-slate-950/90 p-5 rounded-xl border border-slate-800 space-y-3">
                <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>
                    {lang === 'HI' ? 'सोनी के गोल्डन रूल्स (अनिवार्य नियम)' : "Soni's Golden Rules for this Setup"}
                  </span>
                </h4>
                <ul className="space-y-2.5 text-xs text-slate-200">
                  {(lang === 'HI' ? selectedLesson.keyTakeawaysHi : selectedLesson.keyTakeaways).map((point, idx) => (
                    <li key={idx} className="flex items-start space-x-2.5 bg-slate-900/60 p-2.5 rounded-lg border border-slate-800/70">
                      <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span className="leading-relaxed">{point}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* Interactive Pre-Flight Checklist */}
          <div className="bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 rounded-2xl p-6 shadow-xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 flex-wrap gap-2">
              <div className="flex items-center space-x-2">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
                <h4 className="font-extrabold text-sm text-white">
                  {lang === 'HI' ? 'सोनी की प्री-ट्रेड सुरक्षा चेकलिस्ट' : "Soni's Pre-Trade Safety Checklist"}
                </h4>
              </div>
              <span className={`text-xs font-bold font-mono px-2.5 py-1 rounded-full ${
                isTradeApproved 
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
                  : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
              }`}>
                {isTradeApproved 
                  ? (lang === 'HI' ? 'ट्रेड लेने की अनुमति है ✅' : 'APPROVED TO TRADE ✅') 
                  : (lang === 'HI' ? `${completedChecks}/6 चेक पास हुए` : `${completedChecks}/6 Checks Passed`)}
              </span>
            </div>

            <p className="text-xs text-slate-400 mt-2 mb-4">
              {lang === 'HI'
                ? 'ब्रोकर के पास ऑर्डर लगाने से पहले अपने ट्रेड के सभी रूल्स जाँचें। 0% भावनाएँ, 100% अनुशासन।'
                : 'Test your trade confluence before placing the order with your broker. Zero emotions. 100% rule adherence.'}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              {[
                { 
                  key: 'higherTimeframe', 
                  labelEn: 'Higher Timeframe (15m/1h) Trend Aligned',
                  labelHi: 'बड़ा टाइमफ्रेम (15m/1h) एक ही दिशा में अलाइन है'
                },
                { 
                  key: 'vwapConfluence', 
                  labelEn: 'Price is above VWAP (Long) or below VWAP (Short)',
                  labelHi: 'प्राइस VWAP के ऊपर (बाय) या नीचे (सेल) स्थित है'
                },
                { 
                  key: 'sectorAlignment', 
                  labelEn: 'Major heavyweights (Reliance/HDFC) in same direction',
                  labelHi: 'हेवीवेट स्टॉक्स (रिलायंस, एचडीएफसी) ट्रेड के पक्ष में हैं'
                },
                { 
                  key: 'riskUnderTwoPercent', 
                  labelEn: 'Total trade risk is <= 1.5% of account capital',
                  labelHi: 'टोटल ट्रेड का रिस्क कुल पूंजी के 1.5% से कम है'
                },
                { 
                  key: 'stopLossPredefined', 
                  labelEn: 'System Stop-Loss order calculated & set',
                  labelHi: 'सिस्टम स्टॉप-लॉस ऑर्डर पहले से तय और सेट है'
                },
                { 
                  key: 'noRevengeState', 
                  labelEn: 'Calm psychology (not in revenge/FOMO mindset)',
                  labelHi: 'दिमाग शांत है (रिवेंज ट्रेडिंग या फोमो में नहीं हैं)'
                },
              ].map(item => {
                const checked = checklist[item.key as keyof typeof checklist];
                return (
                  <div
                    key={item.key}
                    onClick={() => toggleCheck(item.key as keyof typeof checklist)}
                    className={`p-3 rounded-xl border cursor-pointer transition-all flex items-center space-x-2.5 ${
                      checked 
                        ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-200' 
                        : 'bg-slate-950/60 border-slate-800/80 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <div className={`w-4 h-4 rounded border flex items-center justify-center shrink-0 ${
                      checked ? 'bg-emerald-500 border-emerald-500 text-slate-950' : 'border-slate-700'
                    }`}>
                      {checked && <Check className="w-3 h-3 stroke-[3]" />}
                    </div>
                    <span className="text-[11px] font-medium font-sans">
                      {lang === 'HI' ? item.labelHi : item.labelEn}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
