import { MarketTicker, TradingSignal, CourseModule, CandleData } from '../types/trading';

export const INITIAL_TICKERS: MarketTicker[] = [
  {
    symbol: 'NIFTY 50',
    name: 'NIFTY 50 Index',
    price: 24865.40,
    change: +142.80,
    changePercent: +0.58,
    high24h: 24920.10,
    low24h: 24710.25,
    volume: '185.4M',
    segment: 'options',
    lotSize: 75
  },
  {
    symbol: 'BANKNIFTY',
    name: 'Nifty Bank Index',
    price: 52140.85,
    change: +385.20,
    changePercent: +0.74,
    high24h: 52350.00,
    low24h: 51820.40,
    volume: '94.2M',
    segment: 'options',
    lotSize: 30
  },
  {
    symbol: 'FINNIFTY',
    name: 'Nifty Financial Services',
    price: 23680.15,
    change: +98.40,
    changePercent: +0.42,
    high24h: 23740.00,
    low24h: 23550.00,
    volume: '42.1M',
    segment: 'options',
    lotSize: 65
  },
  {
    symbol: 'RELIANCE',
    name: 'Reliance Industries Ltd',
    price: 2985.50,
    change: +34.20,
    changePercent: +1.16,
    high24h: 2998.00,
    low24h: 2942.00,
    volume: '8.4M',
    segment: 'equity',
    lotSize: 250
  },
  {
    symbol: 'HDFCBANK',
    name: 'HDFC Bank Ltd',
    price: 1682.30,
    change: +14.60,
    changePercent: +0.88,
    high24h: 1694.00,
    low24h: 1665.50,
    volume: '15.1M',
    segment: 'equity',
    lotSize: 550
  },
  {
    symbol: 'TATASTEEL',
    name: 'Tata Steel Ltd',
    price: 154.20,
    change: -1.35,
    changePercent: -0.87,
    high24h: 156.80,
    low24h: 153.10,
    volume: '34.8M',
    segment: 'equity',
    lotSize: 5500
  },
  {
    symbol: 'BTC/USD',
    name: 'Bitcoin Crypto',
    price: 68420.00,
    change: +1240.00,
    changePercent: +1.85,
    high24h: 69150.00,
    low24h: 66800.00,
    volume: '$28.4B',
    segment: 'crypto',
    lotSize: 1
  },
  {
    symbol: 'GOLD (MCX)',
    name: 'Gold Futures 10g',
    price: 78450.00,
    change: +260.00,
    changePercent: +0.33,
    high24h: 78620.00,
    low24h: 78100.00,
    volume: '14.2K',
    segment: 'commodity',
    lotSize: 1
  }
];

export const SEED_SIGNALS: TradingSignal[] = [
  {
    id: 'sig-001',
    title: 'NIFTY 24900 CE Expiry Momentum Breakout',
    symbol: 'NIFTY 24900 CE',
    segment: 'options',
    type: 'BUY',
    entryMin: 145,
    entryMax: 152,
    target1: 180,
    target2: 215,
    target3: 260,
    stopLoss: 120,
    currentPrice: 184,
    status: 'TARGET_1_HIT',
    notes: 'Massive Call unwinding at 24900 and VWAP bounce above day open. Trailing SL to Cost (145).',
    authorId: 'mentor-soni',
    authorName: 'Soni (Head Mentor)',
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    updatedAt: new Date(Date.now() - 1800000).toISOString()
  },
  {
    id: 'sig-002',
    title: 'BANKNIFTY 52000 PE Reversal Setup',
    symbol: 'BANKNIFTY 52000 PE',
    segment: 'options',
    type: 'BUY',
    entryMin: 280,
    entryMax: 295,
    target1: 350,
    target2: 420,
    target3: 510,
    stopLoss: 235,
    currentPrice: 310,
    status: 'ACTIVE',
    notes: 'Resistance rejection at 52350 round level. Target 1 within reach. Strictly follow SL 235.',
    authorId: 'mentor-soni',
    authorName: 'Soni (Head Mentor)',
    createdAt: new Date(Date.now() - 1800000).toISOString(),
    updatedAt: new Date(Date.now() - 600000).toISOString()
  },
  {
    id: 'sig-003',
    title: 'RELIANCE Intraday Long - Triangle Breakout',
    symbol: 'RELIANCE',
    segment: 'equity',
    type: 'BUY',
    entryMin: 2975,
    entryMax: 2985,
    target1: 3015,
    target2: 3045,
    target3: 3080,
    stopLoss: 2950,
    currentPrice: 3020,
    status: 'TARGET_2_HIT',
    notes: 'High volume accumulation near 2975. Both Target 1 and 2 Achieved! Book partial profit and trail SL to 3000.',
    authorId: 'mentor-soni',
    authorName: 'Soni (Head Mentor)',
    createdAt: new Date(Date.now() - 14400000).toISOString(),
    updatedAt: new Date(Date.now() - 3600000).toISOString()
  },
  {
    id: 'sig-004',
    title: 'TATASTEEL Swing Setup - Pullback to 20 EMA',
    symbol: 'TATASTEEL',
    segment: 'equity',
    type: 'BUY',
    entryMin: 153.50,
    entryMax: 154.50,
    target1: 160,
    target2: 165,
    target3: 172,
    stopLoss: 149,
    currentPrice: 154.20,
    status: 'ACTIVE',
    notes: 'Daily timeframe cup & handle retest. Good risk-reward ratio 1:3 for 2-week swing hold.',
    authorId: 'mentor-soni',
    authorName: 'Soni (Head Mentor)',
    createdAt: new Date(Date.now() - 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 86400000).toISOString()
  }
];

export const ACADEMY_MODULES: CourseModule[] = [
  {
    id: 'mod-1',
    title: 'Module 1: Pure Price Action & Candlestick Secrets',
    titleHi: 'मॉड्यूल 1: प्योर प्राइस एक्शन और कैंडलस्टिक के सीक्रेट्स',
    subtitle: 'Decode institutional footprints, traps, and supply-demand imbalances',
    subtitleHi: 'स्मार्ट मनी के फुटप्रिंट्स, ऑपरेटर ट्रैप्स और लिक्विडिटी हंटिंग को समझें',
    iconName: 'CandlestickChart',
    badge: 'Core Foundation',
    badgeHi: 'बेसिक से एडवांस',
    lessons: [
      {
        id: 'les-1',
        order: 1,
        title: 'Anatomy of Rejection Candles & Smart Money Traps',
        titleHi: 'कैंडलस्टिक की बनावट और स्मार्ट मनी ट्रैप्स',
        duration: '22 mins',
        difficulty: 'Beginner',
        summary: 'Learn why classic retail chart patterns fail and how smart money hunts stop losses below key support with long wick rejection candles.',
        summaryHi: 'जानिए क्यों आम रिटेल चार्ट पैटर्न्स फेल होते हैं और कैसे बड़े ऑपरेटर्स सपोर्ट के नीचे फेक विक बनाकर छोटे ट्रेडर्स के स्टॉप लॉस हंट करते हैं।',
        content: 'Institutional players need liquidity to fill massive buy or sell orders. When a strong support level appears on the chart, retail traders place their buy orders with stop-losses just beneath that support. Smart money deliberately pushes prices below the support (creating a long lower shadow or pin bar) to trigger stop losses, absorbs the panic selling, and aggressively rallies the market. Never enter purely because a candle is green; wait for the rejection wick to close above the liquidity sweep level.',
        contentHi: 'बड़े इंस्टीट्यूशनल ऑपरेटर्स को हजारों करोड़ के ऑर्डर्स भरने के लिए लिक्विडिटी (लिक्विड कैश) की ज़रूरत होती है। जब किसी सपोर्ट पर हजारों रिटेल ट्रेडर्स स्टॉप लॉस लगाते हैं, तो ऑपरेटर्स जानबूझकर प्राइस को कुछ सेकंड्स के लिए सपोर्ट के नीचे धकेलते हैं (लंबी विक वाली पिन बार बनती है)। इसके बाद सारा माल सस्ते में खरीदकर मार्केट को ऊपर ले जाते हैं। केवल ग्रीन कैंडल देखकर कभी न कूदें—हमेशा विक रिजेक्शन और क्लोजिंग का इंतज़ार करें।',
        keyTakeaways: [
          'Recognizing false breakdowns (liquidity sweeps) below swing lows',
          'Analyzing wick-to-body ratios: A lower wick covering >60% of the candle indicates aggressive buyer absorption',
          'Setting invalidation levels where institutional bias truly flips instead of standard tight retail stops'
        ],
        keyTakeawaysHi: [
          'स्विंग लो के नीचे होने वाले फेक ब्रेकडाउन (लिक्विडिटी स्वीप) की तुरंत पहचान करें',
          'विक-टू-बॉडी रेश्यो: यदि नीचे की पूंछ (wick) कैंडल के 60% से बड़ी है, तो खरीदार पूरी तरह हावी हैं',
          'अपने स्टॉप-लॉस को ऑपरेटर के हंटिंग ज़ोन से थोड़ा बाहर सुरक्षित रखें'
        ]
      },
      {
        id: 'les-2',
        order: 2,
        title: 'Institutional Supply & Demand Zones vs Retail S&R',
        titleHi: 'इंस्टीट्यूशनल सप्लाई और डिमांड ज़ोन (ऑपरेटर्स का अड्डा)',
        duration: '26 mins',
        difficulty: 'Beginner',
        summary: 'How to mark fresh institutional origin zones where massive unfilled pending limit orders reside.',
        summaryHi: 'जानिए कैसे चार्ट पर असली फ्रेश डिमांड और सप्लाई ज़ोन मार्क किए जाते हैं जहाँ बैंकों के हजारों पेंडिंग ऑर्डर्स लगे होते हैं।',
        content: 'Retail support and resistance lines are arbitrary single horizontal price lines that get violated frequently. Institutional supply and demand zones are defined as ranges where an explosive imbalance previously occurred. Look for clean Rally-Base-Rally (Demand) or Drop-Base-Drop (Supply) structures on 15-minute and 1-hour charts. When price returns to a fresh (untested) zone for the first time, expect high-velocity reactionary bounces.',
        contentHi: 'साधारण सपोर्ट और रेजिस्टेंस केवल एक पतली लाइन होती है जो अक्सर टूट जाती है। इसके विपरीत इंस्टीट्यूशनल सप्लाई और डिमांड एक पूरा दायरा (Zone) होता है जहाँ से मार्केट में अचानक बहुत तेज़ धमाका हुआ हो। 15-मिनट और 1-घंटे के चार्ट पर Rally-Base-Rally (डिमांड) या Drop-Base-Drop (सप्लाई) की पहचान करें। जब प्राइस पहली बार इस फ्रेश ज़ोन में वापस आता है, तो बहुत तेज़ बाउंस मिलता है।',
        keyTakeaways: [
          'Differentiating between fresh (untested) zones and exhausted (tested 3+ times) zones',
          'Spotting the decisive "Base Candle" before the explosive institutional candle',
          'Trading the first retest with high confidence and a tight 1:3 Risk-to-Reward ratio'
        ],
        keyTakeawaysHi: [
          'फ्रेश (पहली बार टेस्ट हो रहे) ज़ोन और घिसे हुए (3 से ज्यादा बार टेस्टेड) ज़ोन में अंतर पहचानें',
          'तेज़ ब्रेकआउट कैंडल से ठीक पहले बनी छोटी "बेस कैंडल" को मार्क करें',
          'ज़ोन के पहले री-टेस्ट पर 1:3 रिस्क-रिवॉर्ड के साथ स्नाइपर एंट्री प्लान करें'
        ]
      },
      {
        id: 'les-3',
        order: 3,
        title: 'False Breakouts & Liquidity Traps Masterclass',
        titleHi: 'फेक ब्रेकआउट और लिक्विडिटी ट्रैप्स की पहचान',
        duration: '30 mins',
        difficulty: 'Intermediate',
        summary: 'Master the art of avoiding bull and bear traps, and learn how to trade the reversal after retail traders get trapped.',
        summaryHi: 'बुल ट्रैप और बेयर ट्रैप में फँसने से बचें और सीखें कि जब रिटेल ट्रेडर्स ट्रैप होते हैं तो उल्टी दिशा में बड़ा ट्रेड कैसे पकड़ें।',
        content: 'When an obvious resistance breaks during the first 15 minutes of trading with declining volume, 90% of retail breakout buyers jump in with market orders. If the next 5-minute candle immediately prints an inverted hammer or closes back inside the previous consolidation range, a massive Bull Trap has occurred. The fastest profits in trading come from trading the trapped traders\' stop-loss liquidations.',
        contentHi: 'जब बाज़ार खुलते ही किसी बड़ी रेजिस्टेंस के ऊपर कम वॉल्यूम के साथ ब्रेकआउट होता है, तो रिटेल ट्रेडर्स लालच में आकर सीधे बाय कर लेते हैं। यदि अगली 5-मिनट की कैंडल तुरंत रेंज के अंदर वापस क्लोज़ हो जाती है, तो यह क्लासिक "बुल ट्रैप" है। सबसे तेज़ और बड़ा प्रॉफिट तब बनता है जब आप ट्रैप हुए ट्रेडर्स के पैनिक में एग्जिट करने की दिशा में ट्रेड लेते हैं।',
        keyTakeaways: [
          'Never buy a breakout immediately on candle open; wait for the full candle closing validation',
          'Volume divergence check: If price makes a new high but volume dries up, expect a fakeout trap',
          'The Trapped Trader Setup: Enter in the opposite direction the moment price breaks back into the consolidation range'
        ],
        keyTakeawaysHi: [
          'कैंडल शुरू होते ही कभी न कूदें—हमेशा 5-मिनट कैंडल पूरी बंद होने की प्रतीक्षा करें',
          'वॉल्यूम डायवर्जेंस: नया हाई बनते समय यदि वॉल्यूम गिर रहा है, तो समझ जाएँ कि बड़ा ट्रैप होने वाला है',
          'ट्रैप्ड ट्रेडर एंट्री: रेंज में प्राइस के वापस घुसते ही उल्टी दिशा में ट्रेड लें'
        ]
      }
    ]
  },
  {
    id: 'mod-2',
    title: 'Module 2: Soni\'s High-Probability Intraday Setups',
    titleHi: 'मॉड्यूल 2: सोनी के हाई-प्रोबेबिलिटी इंट्राडे सेटअप्स',
    subtitle: 'Proven rule-based strategies for Nifty, BankNifty and leading stocks',
    subtitleHi: 'निफ्टी, बैंक निफ्टी और स्टॉक्स के लिए 100% नियम-आधारित ट्रेडिंग स्ट्रैटेजी',
    iconName: 'Zap',
    badge: 'Signature Setups',
    badgeHi: 'सोनी स्पेशल',
    lessons: [
      {
        id: 'les-4',
        order: 4,
        title: 'Central Pivot Range (CPR) Secrets & Day Trend Prediction',
        titleHi: 'CPR का सीक्रेट - 9:15 AM पर पूरे दिन के ट्रेंड की भविष्यवाणी',
        duration: '28 mins',
        difficulty: 'Intermediate',
        summary: 'Using daily CPR width (Narrow vs Wide) to forecast whether the market will trend 300+ points or remain in a sideways chop.',
        summaryHi: 'डेली CPR की चौड़ाई (Narrow बनाम Wide) से सुबह 9:15 पर ही तय करें कि आज 300 पॉइंट का बड़ा ट्रेंड मिलेगा या बाज़ार साइडवेज़ रहेगा।',
        content: 'The Central Pivot Range (TC, Pivot, BC) calculates institutional consensus from the previous trading day. When today\'s CPR is extraordinarily narrow (TC and BC almost touching), it indicates price contraction and guarantees an explosive trending day—ideal for option buyers. When CPR is wide, the market is prone to range-bound mean reversion, where option buyers lose to theta decay and option sellers dominate.',
        contentHi: 'सेंट्रल पिवट रेंज (TC, Pivot, BC) पिछले दिन की वॉल्यूम और प्राइस का निचोड़ होती है। जब आज का CPR बहुत पतला (Narrow) होता है, तो उस दिन 85% संभावना होती है कि निफ्टी/बैंकनिफ्टी में एक तरफा 200-400 पॉइंट की रैली होगी—यह ऑप्शन बायर्स के लिए वरदान है। वहीं जब CPR बहुत चौड़ा (Wide) हो, तो मार्केट चॉपी रहता है और ऑप्शन बायर्स का प्रीमियम गल जाता है।',
        keyTakeaways: [
          'Narrow CPR = Aggressive trending day ahead; look for 9:20 AM momentum breakouts',
          'Wide CPR = Sideways market; avoid option buying, scalp only at extremes',
          'Virgin CPR (untested during the day) acts as an infallible magnetic target in future sessions'
        ],
        keyTakeawaysHi: [
          'संकीर्ण (Narrow) CPR = बड़ा ट्रेंडिंग दिन; 9:20 AM ब्रेकआउट पर कॉल/पुट बाय करें',
          'चौड़ा (Wide) CPR = साइडवेज़ चॉप; बड़े टारगेट्स का लालच न करें, केवल सपोर्ट/रेजिस्टेंस पर स्कैल्प करें',
          'वर्जिन CPR (जो आज टच नहीं हुआ) आने वाले दिनों में लोहे की तरह मजबूत मैग्नेट का काम करता है'
        ]
      },
      {
        id: 'les-5',
        order: 5,
        title: 'Soni\'s Signature 9:20 AM Range Breakout Strategy',
        titleHi: 'सोनी का 9:20 AM ब्रेकआउट सेटअप (निफ्टी और बैंक निफ्टी)',
        duration: '35 mins',
        difficulty: 'Intermediate',
        summary: 'The exact step-by-step checklist to trade the first directional impulse of the market with zero confusion.',
        summaryHi: 'सुबह के पहले 15-30 मिनट में मिलने वाले 100-300 पॉइंट के पहले बड़े मूव को पकड़ने का सटीक नियम-आधारित चेकलिस्ट।',
        content: 'At 9:15 AM, the market opens with high initial volatility. Mark the High and Low of the first 5-minute candle (9:15 AM - 9:20 AM). Do NOT trade inside this range. When the second or third candle decisively closes outside the range WITH sectoral breadth confirmation (e.g., Reliance for Nifty or HDFC Bank for Bank Nifty), enter in the direction of the breakout. Keep Stop Loss at the midpoint of the first candle or opposite extreme for a guaranteed 1:2.5 Risk-to-Reward ratio.',
        contentHi: 'सुबह 9:15 पर मार्केट में बहुत शोर होता है। पहली 5-मिनट की कैंडल (9:15 से 9:20 AM) का हाई और लो दोनों मार्क कर लें। इसके बीच में कभी ट्रेड न लें। जैसे ही अगली कोई कैंडल इस रेंज के ऊपर या नीचे पूरी क्लोज़िंग देती है और बड़े हेवीवेट स्टॉक्स (जैसे रिलायंस या एचडीएफसी बैंक) भी उसी दिशा में हों, तो तुरंत एंट्री लें। स्टॉप-लॉस पहली कैंडल के आधे पर रखें और न्यूनतम 1:2.5 का टारगेट लें।',
        keyTakeaways: [
          'The first 5-minute candle high & low mark the battlefield boundaries',
          'Confirmation check: Both Nifty and Bank Nifty must break out in synchronization',
          'If first candle exceeds 150 points on Bank Nifty, wait for a pullback to range boundary instead of chasing at the top'
        ],
        keyTakeawaysHi: [
          'पहली 5-मिनट कैंडल का हाई और लो आपके दिन का लक्ष्मण रेखा है',
          'दोनों इंडेक्स (निफ्टी और बैंक निफ्टी) का एक ही दिशा में ब्रेकआउट होना ज़रूरी है',
          'यदि पहली कैंडल बहुत बड़ी बन जाए, तो ऊपर भागने के बजाय री-टेस्ट का इंतज़ार करें'
        ]
      },
      {
        id: 'les-6',
        order: 6,
        title: '3-Minute VWAP Trapping & Sniper Reversals',
        titleHi: '3-मिनट VWAP ट्रैपिंग और स्नाइपर एंट्रीज',
        duration: '30 mins',
        difficulty: 'Advanced',
        summary: 'How to enter precision trades when price retests the Volume-Weighted Average Price with diminishing volume.',
        summaryHi: 'जानिए कैसे VWAP (वॉल्यूम वेटेड एवरेज प्राइस) के पुलबैक पर 10-15 पॉइंट के छोटे स्टॉप लॉस के साथ बड़ा मूव पकड़ा जाता है।',
        content: 'VWAP is the benchmark used by institutional algorithmic order flow. If price rallies in the morning, extended retail buyers get exhausted. When price gently pulls back to touch the rising VWAP line on the 3-minute timeframe and forms a rejection pin bar with decreasing selling volume, institutions step in to accumulate more contracts at the fair benchmark. This gives the tightest risk-to-reward ratio in intraday trading.',
        contentHi: 'VWAP वह एवरेज प्राइस है जिस पर दुनिया के सबसे बड़े म्यूचुअल फंड्स और एल्गो बॉट्स ट्रेड करते हैं। जब मार्केट ऊपर जाकर वापस आराम से गिरते हुए VWAP लाइन को छूता है और वहां 3-मिनट की हैमर या पिन बार बनाता है (कम वॉल्यूम के साथ), तो बड़े ऑपरेटर्स दोबारा भारी खरीदारी करते हैं। यहाँ एंट्री करने से स्टॉप लॉस बहुत छोटा (सिर्फ 10-15 पॉइंट) और प्रॉफिट 50-100 पॉइंट तक मिलता है।',
        keyTakeaways: [
          'Price above rising VWAP = Bullish bias only (Search for Call buying setups)',
          'Price below falling VWAP = Bearish bias only (Search for Put buying setups)',
          'Never initiate a fresh long trade if price is stretched more than 2 standard deviations away from VWAP'
        ],
        keyTakeawaysHi: [
          'प्राइस यदि VWAP के ऊपर चल रहा है = केवल कॉल (BUY) के मौके ढूँढें',
          'प्राइस यदि VWAP के नीचे चल रहा है = केवल पुट (SELL) के मौके ढूँढें',
          'VWAP से बहुत दूर भाग चुकी मार्केट में कभी भी नया लॉन्ग ट्रेड न लें—पुलबैक का इंतज़ार करें'
        ]
      }
    ]
  },
  {
    id: 'mod-3',
    title: 'Module 3: Options Buying Matrix & OI Decoder',
    titleHi: 'मॉड्यूल 3: ऑप्शन बाइंग मैट्रिक्स और ओपन इंटरेस्ट डिकोडर',
    subtitle: 'Overcome Theta decay and catch explosive Delta & Gamma momentum',
    subtitleHi: 'थीटा डीके (प्रीमियम गलन) से बचें और डेल्टा व गामा मोमेंटम से पैसा बनाएं',
    iconName: 'Activity',
    badge: 'Pro Derivatives',
    badgeHi: 'डेरिवेटिव्स प्रो',
    lessons: [
      {
        id: 'les-7',
        order: 7,
        title: 'Options Buying Secrets & Eliminating Theta Decay',
        titleHi: 'ऑप्शन बाइंग के सीक्रेट्स और सही स्ट्राइक का चयन',
        duration: '38 mins',
        difficulty: 'Intermediate',
        summary: 'Stop buying cheap deep Out-of-the-Money (OTM) options. Master ATM and ITM Delta dynamics to ensure you profit on every point the index moves.',
        summaryHi: 'सस्ते OTM ऑप्शंस खरीदना बंद करें। ATM और ITM स्ट्राइक चुनना सीखें जिससे इंडेक्स के हर 10 पॉइंट पर आपका ऑप्शन तेज़ी से बढ़े।',
        content: 'The number one mistake retail option buyers make is buying ₹15 or ₹20 deep OTM options hoping for a miracle. These options have a Delta of 0.15, meaning even if Nifty moves 50 points, the option moves barely 7 points while Theta decay destroys the remaining value. Professional option buyers strictly trade At-The-Money (ATM) or In-The-Money (ITM) strikes with a Delta of 0.50 to 0.70 during fast momentum bursts.',
        contentHi: '90% रिटेल ऑप्शन बायर्स ₹10-₹20 वाले बहुत दूर के सस्ते OTM ऑप्शंस खरीदते हैं और सोचते हैं कि ये 10 गुना हो जाएगा। इनका डेल्टा सिर्फ 0.10 से 0.15 होता है—यानी निफ्टी 50 पॉइंट भी चढ़ जाए तो यह केवल 5-7 पॉइंट ही बढ़ेगा और शाम तक टाइम डीके (Theta) इसे ज़ीरो कर देगा। असली प्रोफेशनल हमेशा ATM (At The Money) या हल्की ITM स्ट्राइक चुनते हैं जिनका डेल्टा 0.50+ होता है।',
        keyTakeaways: [
          'Always buy ATM (Delta ~0.50) or slightly ITM (Delta ~0.60) for intraday momentum trades',
          'Never hold buying positions in sideways consolidating sessions—exit after 3 stagnant candles',
          'Best trading hours for option buyers: 9:15 AM to 10:45 AM and 1:30 PM to 3:15 PM'
        ],
        keyTakeawaysHi: [
          'इंट्राडे मोमेंटम के लिए हमेशा ATM या हल्की ITM स्ट्राइक ही खरीदें',
          'यदि मार्केट साइडवेज़ हो जाए, तो ऑप्शन बाइंग पोजीशन में जबरदस्ती बैठे न रहें—तुरंत एग्जिट करें',
          'ऑप्शन बाइंग के लिए सबसे बेहतरीन समय: सुबह 9:15 से 10:45 और दोपहर 1:30 से 3:15'
        ]
      },
      {
        id: 'les-8',
        order: 8,
        title: 'Open Interest (OI) & Put-Call Ratio (PCR) Decoded',
        titleHi: 'ओपन इंटरेस्ट (OI) और PCR डिकोडर - बड़े राइटर्स के चक्रव्यूह को समझें',
        duration: '42 mins',
        difficulty: 'Intermediate',
        summary: 'How to read live NSE option chain data to pinpoint exact institutional support and resistance strike prices.',
        summaryHi: 'लाइव NSE ऑप्शन चेन से जानें कि बड़े राइटर्स ने कहाँ पर मजबूत दीवार (सपोर्ट व रेजिस्टेंस) खड़ी की है।',
        content: 'Option sellers are well-capitalized institutions. When Call Open Interest builds up massively at a particular strike (e.g. 25,000 Call), institutions are betting that price will not cross 25,000 before expiry. Conversely, heavy Put writing at 24,800 creates a solid floor. The Put-Call Ratio (Total Put OI / Total Call OI) gives immediate macro sentiment: Below 0.70 means market is oversold (watch for short-covering rally); above 1.35 means market is overbought.',
        contentHi: 'ऑप्शन सेलर (राइटर्स) बड़े बैंक्स और करोड़ों वाले फंड्स होते हैं। जब 25,000 की कॉल पर भारी मात्रा में Open Interest जुड़ता है, तो इसका मतलब है कि उन्होंने रेजिस्टेंस की मजबूत दीवार बना दी है। वहीं जब 24,800 की पुट पर ओपन इंटरेस्ट बढ़ता है, तो वह सबसे मजबूत सपोर्ट बनता है। PCR (Put-Call Ratio) यदि 0.65 से नीचे गिरे तो बाज़ार ओवरसोल्ड है और बाउंस आने वाला है; 1.40 के ऊपर हो तो प्रॉफिट बुकिंग की तैयारी करें।',
        keyTakeaways: [
          'Call OI addition = Resistance wall strengthening',
          'Call OI unwinding (negative change in OI) = Explosive short covering rally impending',
          'PCR below 0.70 indicates panic bottom; PCR above 1.35 warns of exhaustion tops'
        ],
        keyTakeawaysHi: [
          'कॉल OI में बढ़ोतरी = रेजिस्टेंस की दीवार और मजबूत हो रही है',
          'कॉल राइटर्स का भागना (Unwinding) = बहुत बड़ा शॉर्ट कवरिंग धमाका आने वाला है',
          'PCR 0.70 के नीचे = ओवरसोल्ड बाज़ार (बाय ऑन डिप्स); PCR 1.35 के ऊपर = ओवरबॉट बाज़ार'
        ]
      },
      {
        id: 'les-9',
        order: 9,
        title: 'Expiry Day 1:30 PM Hero-or-Zero Strategy & Gamma Blast',
        titleHi: 'एक्सपायरी डे 1:30 PM हीरो-जीरो सेटअप और गामा ब्लास्ट',
        duration: '45 mins',
        difficulty: 'Advanced',
        summary: 'How to capture 100% to 300% ROI on Thursday and Wednesday expiries using mathematical Gamma bursts with strictly limited risk.',
        summaryHi: 'एक्सपायरी के दिन दोपहर 1:30 बजे ₹20-₹30 वाले ऑप्शन का ₹80-₹120 में बदलने वाला गामा ब्लास्ट कैसे पकड़ें।',
        content: 'On expiry day after 1:30 PM, extrinsic time value drops close to zero. If an index breaks out beyond a major Open Interest strike cluster, option writers are forced to cover their positions simultaneously in panic. This sudden demand causes the option\'s Gamma to explode, turning a ₹25 strike into ₹100+ within 15 minutes. The strict rule: Allocate no more than 1.5% of your total trading capital to any Hero-Zero setup, and trail your stop-loss to cost immediately upon reaching 100% gain.',
        contentHi: 'एक्सपायरी के दिन दोपहर 1:30 के बाद टाइम वैल्यू लगभग खत्म हो जाती है। यदि उस समय निफ्टी या बैंकनिफ्टी किसी बड़ी स्ट्राइक की रेंज को तोड़ता है, तो हज़ारों कॉल राइटर्स को अपने सौदे लॉस में काटने पड़ते हैं। इस पैनिक की वजह से "गामा ब्लास्ट" होता है और ₹25 का प्रीमियम 15 मिनट में ₹90-₹120 पहुँच जाता है। नियम: इसमें अपनी पूरी पूंजी का केवल 1.5% ही लगाएं और 100% प्रॉफिट मिलते ही स्टॉप-लॉस को कॉस्ट पर ट्रेल कर लें।',
        keyTakeaways: [
          'Timing is everything: Look for setup triggers strictly between 1:15 PM and 2:30 PM on expiry day',
          'Target strikes where OI difference is highest to trigger maximum short-covering panic',
          'Capital allocation rule: Never risk your weekly profits on a single hero-zero attempt'
        ],
        keyTakeawaysHi: [
          'टाइमिंग सबसे महत्वपूर्ण है: केवल दोपहर 1:15 से 2:30 के बीच ही सेटअप ढूंढें',
          'उस स्ट्राइक को चुनें जहाँ सबसे ज्यादा राइटर्स ट्रैप होने वाले हों',
          'पूंजी नियम: हफ्ते भर का कमाया हुआ प्रॉफिट एक हीरो-जीरो ट्रेड में कभी दांव पर न लगाएं'
        ]
      }
    ]
  },
  {
    id: 'mod-4',
    title: 'Module 4: Risk Management & The Winner\'s Psychology',
    titleHi: 'मॉड्यूल 4: रिस्क मैनेजमेंट और विनर ट्रेडर की साइकोलॉजी',
    subtitle: 'The mathematical edge and emotional discipline of the profitable 1%',
    subtitleHi: 'प्रॉफिटेबल 1% ट्रेडर्स का गणितीय नियम और अटूट अनुशासन',
    iconName: 'ShieldCheck',
    badge: 'Crucial Mindset',
    badgeHi: 'माइंडसेट और अनुशासन',
    lessons: [
      {
        id: 'les-10',
        order: 10,
        title: 'The Invariant 1% Risk Rule & Eradicating Revenge Trading',
        titleHi: '1% रिस्क नियम और ट्रेडिंग माइंडसेट - रिवेंज ट्रेडिंग का अंत',
        duration: '35 mins',
        difficulty: 'Beginner',
        summary: 'Why position sizing is 10x more important than entry accuracy, and how to operate like a calm, disciplined professional business.',
        summaryHi: 'क्यों पोजीशन साइजिंग आपकी एंट्री से 10 गुना ज्यादा महत्वपूर्ण है और कैसे रिवेंज ट्रेडिंग व फोमो (FOMO) से हमेशा के लिए छुटकारा पाएं।',
        content: 'Professional trading is a game of mathematics, capital preservation, and emotional regulation. If you risk 10% per trade, 3 consecutive losses wipe out one-third of your account. If you risk strictly 1% per trade, 3 losses barely dent 3% of your capital, leaving your psychology intact. Implement a daily circuit breaker: If you take 2 consecutive losses in a day, shut down your trading terminal immediately. The market will be there tomorrow; your capital might not if you revenge trade.',
        contentHi: 'ट्रेडिंग कोई जुआ नहीं, एक गणितीय बिजनेस है। यदि आप एक ट्रेड में अपनी 10% पूंजी रिस्क पर लगाते हैं, तो लगातार 3 गलत ट्रेड आपका एक-तिहाई अकाउंट खाली कर देंगे। लेकिन यदि आप प्रत्येक ट्रेड पर केवल 1% रिस्क लेते हैं, तो 3 लॉस के बाद भी आपका 97% कैपिटल सुरक्षित रहता है और आपका दिमाग शांत रहता है। डेली सर्किट ब्रेकर नियम: यदि दिन में 2 लगातार स्टॉप-लॉस हिट हो जाएं, तो तुरंत लैपटॉप/मोबाइल बंद कर दें। मार्केट कल भी खुलेगा, लेकिन आपकी पूंजी खत्म हो सकती है।',
        keyTakeaways: [
          'The Invariant 1% Rule: Never risk more than 1% to 1.5% of total capital on any single setup',
          'Daily Circuit Breaker: Maximum 2 losses per day. Close the screen and step away',
          'The Trade Journal Habit: Log every trade with emotion rating (Calm, FOMO, Revenge) to uncover behavioral leaks'
        ],
        keyTakeawaysHi: [
          'अटल 1% नियम: किसी भी एक ट्रेड में अपनी कुल पूंजी का 1.5% से अधिक रिस्क कभी न लें',
          'डेली सर्किट ब्रेकर: दिन में 2 स्टॉप-लॉस हिट होने के बाद स्क्रीन बंद कर दें',
          'ट्रेड जर्नल आदत: हर ट्रेड के बाद अपनी मानसिक स्थिति (शांत, लालच, गुस्सा) लिखें ताकि गलतियों की पुनरावृत्ति न हो'
        ]
      }
    ]
  }
];

export function generateCandles(basePrice: number, count: number = 40): CandleData[] {
  const candles: CandleData[] = [];
  let currentPrice = basePrice * 0.985;
  const now = Date.now();
  const intervalMs = 5 * 60 * 1000;

  for (let i = count; i >= 0; i--) {
    const time = new Date(now - i * intervalMs).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const volatility = basePrice * 0.0035;
    const delta = (Math.random() - 0.47) * volatility;
    const open = Number(currentPrice.toFixed(2));
    const close = Number((open + delta).toFixed(2));
    const high = Number((Math.max(open, close) + Math.random() * volatility * 0.7).toFixed(2));
    const low = Number((Math.min(open, close) - Math.random() * volatility * 0.7).toFixed(2));
    const volume = Math.floor(Math.random() * 80000 + 15000);

    candles.push({ time, open, high, low, close, volume });
    currentPrice = close;
  }
  return candles;
}
