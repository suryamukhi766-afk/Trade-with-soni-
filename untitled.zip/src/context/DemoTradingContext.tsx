import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { DemoPosition, DemoOrderHistory, MarketSegment } from '../types/trading';

export interface OrderResult {
  success: boolean;
  error?: string;
}

export const calculateRequiredMargin = (price: number, quantity: number, segment: MarketSegment): number => {
  if (price <= 0 || quantity <= 0) return 0;
  switch (segment) {
    case 'options':
    case 'futures':
      // 10% SPAN & exposure margin for index derivatives (e.g. ₹1.86L for Nifty 1 lot of 75 qty)
      return Number((price * quantity * 0.10).toFixed(2));
    case 'equity':
      // 20% Intraday MIS margin (5x leverage) for equities
      return Number((price * quantity * 0.20).toFixed(2));
    case 'commodity':
    case 'crypto':
      return Number((price * quantity * 0.10).toFixed(2));
    default:
      return Number((price * quantity).toFixed(2));
  }
};

interface DemoTradingContextType {
  balance: number;
  initialBalance: number;
  positions: DemoPosition[];
  orderHistory: DemoOrderHistory[];
  realizedPnl: number;
  unrealizedPnl: number;
  usedMargin: number;
  calculateMargin: (price: number, quantity: number, segment: MarketSegment) => number;
  openPosition: (order: {
    symbol: string;
    segment: MarketSegment;
    type: 'BUY' | 'SELL';
    price: number;
    quantity: number;
    lotSize: number;
    targetPrice?: number;
    stopLossPrice?: number;
  }) => OrderResult;
  closePosition: (positionId: string, currentExitPrice?: number, reason?: 'MANUAL' | 'TARGET_HIT' | 'SL_HIT') => void;
  resetDemoAccount: () => void;
  updatePositionPrices: (symbol: string, currentPrice: number) => void;
  notification: string | null;
  clearNotification: () => void;
}

const DEMO_STORAGE_KEY = 'tws_demo_trading_state_v1';
const INITIAL_VIRTUAL_CAPITAL = 1000000; // ₹10,00,000 (10 Lakhs)

const DemoTradingContext = createContext<DemoTradingContextType | undefined>(undefined);

export const DemoTradingProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [balance, setBalance] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(DEMO_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (typeof parsed.balance === 'number' && parsed.balance > 0) {
          return parsed.balance;
        }
      }
    } catch (_) {}
    return INITIAL_VIRTUAL_CAPITAL;
  });

  const [positions, setPositions] = useState<DemoPosition[]>(() => {
    try {
      const saved = localStorage.getItem(DEMO_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return Array.isArray(parsed.positions) ? parsed.positions : [];
      }
    } catch (_) {}
    return [];
  });

  const [orderHistory, setOrderHistory] = useState<DemoOrderHistory[]>(() => {
    try {
      const saved = localStorage.getItem(DEMO_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return Array.isArray(parsed.orderHistory) ? parsed.orderHistory : [];
      }
    } catch (_) {}
    return [];
  });

  const [notification, setNotification] = useState<string | null>(null);
  const lastOrderRef = useRef<{ key: string; time: number }>({ key: '', time: 0 });

  // Sync to local storage
  useEffect(() => {
    try {
      localStorage.setItem(
        DEMO_STORAGE_KEY,
        JSON.stringify({ balance, positions, orderHistory })
      );
    } catch (_) {}
  }, [balance, positions, orderHistory]);

  const clearNotification = () => setNotification(null);

  // Calculate Used Margin based on individual position margin or segment rule
  const usedMargin = positions.reduce(
    (acc, pos) => acc + (pos.margin ?? calculateRequiredMargin(pos.entryPrice, pos.quantity, pos.segment)),
    0
  );

  // Calculate Realized PnL
  const realizedPnl = orderHistory.reduce((acc, ord) => acc + ord.pnl, 0);

  // Calculate Unrealized PnL
  const unrealizedPnl = positions.reduce((acc, pos) => {
    const diff = pos.type === 'BUY' 
      ? pos.currentPrice - pos.entryPrice 
      : pos.entryPrice - pos.currentPrice;
    return acc + diff * pos.quantity;
  }, 0);

  const openPosition = (order: {
    symbol: string;
    segment: MarketSegment;
    type: 'BUY' | 'SELL';
    price: number;
    quantity: number;
    lotSize: number;
    targetPrice?: number;
    stopLossPrice?: number;
  }): OrderResult => {
    // 1. Validate Symbol
    if (!order.symbol || typeof order.symbol !== 'string' || order.symbol.trim() === '') {
      const err = 'Invalid Asset: Please select a valid instrument.';
      setNotification(`❌ ${err}`);
      return { success: false, error: err };
    }

    // 2. Validate Price
    if (!order.price || order.price <= 0 || isNaN(order.price)) {
      const err = `Invalid Price: Current price for ${order.symbol} is invalid.`;
      setNotification(`❌ ${err}`);
      return { success: false, error: err };
    }

    // 3. Validate Quantity
    if (!order.quantity || order.quantity <= 0 || isNaN(order.quantity) || !Number.isInteger(order.quantity)) {
      const err = 'Invalid Quantity: Quantity must be a positive whole number.';
      setNotification(`❌ ${err}`);
      return { success: false, error: err };
    }

    // 4. Duplicate Order Prevention Guard (prevent rapid double clicks within 800ms)
    const now = Date.now();
    const orderKey = `${order.symbol}-${order.type}-${order.quantity}-${order.price.toFixed(1)}`;
    if (now - lastOrderRef.current.time < 800 && lastOrderRef.current.key === orderKey) {
      const err = 'Duplicate order prevented. Please wait before placing the same trade.';
      setNotification(`⚠️ ${err}`);
      return { success: false, error: err };
    }
    lastOrderRef.current = { key: orderKey, time: now };

    // 5. Margin Requirement Calculation
    const requiredMargin = calculateRequiredMargin(order.price, order.quantity, order.segment);

    // 6. Balance Verification
    if (requiredMargin > balance) {
      const err = `Insufficient Demo Balance! Required Margin: ₹${requiredMargin.toLocaleString('en-IN', { maximumFractionDigits: 0 })}, Available: ₹${balance.toLocaleString('en-IN', { maximumFractionDigits: 0 })}.`;
      setNotification(`❌ ${err}`);
      return { success: false, error: err };
    }

    // 7. Execute Virtual Trade
    const newPosition: DemoPosition = {
      id: `pos-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      symbol: order.symbol.trim(),
      segment: order.segment,
      type: order.type,
      entryPrice: Number(order.price.toFixed(2)),
      currentPrice: Number(order.price.toFixed(2)),
      quantity: order.quantity,
      lotSize: order.lotSize,
      margin: requiredMargin,
      targetPrice: order.targetPrice ? Number(order.targetPrice.toFixed(2)) : undefined,
      stopLossPrice: order.stopLossPrice ? Number(order.stopLossPrice.toFixed(2)) : undefined,
      timestamp: new Date().toISOString(),
    };

    setBalance(prev => Number(Math.max(0, prev - requiredMargin).toFixed(2)));
    setPositions(prev => [newPosition, ...prev]);
    setNotification(
      `✅ Paper Order Executed: ${order.type} ${order.quantity} qty of ${order.symbol} @ ₹${order.price.toFixed(2)} (Margin: ₹${requiredMargin.toLocaleString('en-IN', { maximumFractionDigits: 0 })})`
    );

    // Audio chime feedback
    try {
      const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
      audio.volume = 0.35;
      audio.play().catch(() => {});
    } catch (_) {}

    return { success: true };
  };

  const closePosition = (
    positionId: string, 
    currentExitPrice?: number, 
    reason: 'MANUAL' | 'TARGET_HIT' | 'SL_HIT' = 'MANUAL'
  ) => {
    const target = positions.find(p => p.id === positionId);
    if (!target) return;

    const exitPrice = currentExitPrice ?? target.currentPrice;
    const diff = target.type === 'BUY' 
      ? exitPrice - target.entryPrice 
      : target.entryPrice - exitPrice;
    const pnl = Number((diff * target.quantity).toFixed(2));
    const pnlPercent = Number(((diff / target.entryPrice) * 100).toFixed(2));

    const positionMargin = target.margin ?? calculateRequiredMargin(target.entryPrice, target.quantity, target.segment);
    const returnedCapital = Number((positionMargin + pnl).toFixed(2));

    const completedOrder: DemoOrderHistory = {
      id: `ord-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      symbol: target.symbol,
      type: target.type,
      entryPrice: target.entryPrice,
      exitPrice: exitPrice,
      quantity: target.quantity,
      pnl: pnl,
      pnlPercent: pnlPercent,
      entryTime: target.timestamp,
      exitTime: new Date().toISOString(),
      exitReason: reason,
    };

    setPositions(prev => prev.filter(p => p.id !== positionId));
    setBalance(prev => Math.max(0, Number((prev + returnedCapital).toFixed(2))));
    setOrderHistory(prev => [completedOrder, ...prev]);

    const reasonLabel = reason === 'TARGET_HIT' ? '🎯 Target Hit' : reason === 'SL_HIT' ? '🛑 Stop Loss Hit' : 'Squared Off';
    setNotification(`${reasonLabel}: ${target.symbol} ${pnl >= 0 ? '+' : ''}₹${pnl.toLocaleString('en-IN')} (${pnlPercent}%)`);
  };

  // Live market price simulation tick updater
  const updatePositionPrices = (symbol: string, currentPrice: number) => {
    if (!symbol || currentPrice <= 0) return;

    setPositions(prev => {
      let hasChanges = false;
      const updated = prev.map(pos => {
        if (pos.symbol === symbol && pos.currentPrice !== currentPrice) {
          hasChanges = true;

          // Check if Target Hit
          if (pos.targetPrice) {
            const isTargetReached = pos.type === 'BUY' 
              ? currentPrice >= pos.targetPrice 
              : currentPrice <= pos.targetPrice;
            if (isTargetReached) {
              setTimeout(() => closePosition(pos.id, pos.targetPrice, 'TARGET_HIT'), 80);
            }
          }

          // Check if Stop Loss Hit
          if (pos.stopLossPrice) {
            const isSlReached = pos.type === 'BUY' 
              ? currentPrice <= pos.stopLossPrice 
              : currentPrice >= pos.stopLossPrice;
            if (isSlReached) {
              setTimeout(() => closePosition(pos.id, pos.stopLossPrice, 'SL_HIT'), 80);
            }
          }

          return { ...pos, currentPrice };
        }
        return pos;
      });
      return hasChanges ? updated : prev;
    });
  };

  const resetDemoAccount = () => {
    if (window.confirm('Are you sure you want to reset your Demo Account to ₹10,00,000? All virtual positions and history will be cleared.')) {
      setBalance(INITIAL_VIRTUAL_CAPITAL);
      setPositions([]);
      setOrderHistory([]);
      setNotification('🔄 Demo Account Reset to ₹10,00,000 Virtual Capital.');
    }
  };

  return (
    <DemoTradingContext.Provider
      value={{
        balance,
        initialBalance: INITIAL_VIRTUAL_CAPITAL,
        positions,
        orderHistory,
        realizedPnl,
        unrealizedPnl,
        usedMargin,
        calculateMargin: calculateRequiredMargin,
        openPosition,
        closePosition,
        resetDemoAccount,
        updatePositionPrices,
        notification,
        clearNotification,
      }}
    >
      {children}
    </DemoTradingContext.Provider>
  );
};

export const useDemoTrading = () => {
  const context = useContext(DemoTradingContext);
  if (!context) {
    throw new Error('useDemoTrading must be used within a DemoTradingProvider');
  }
  return context;
};
